create definer = admin@localhost trigger maj_total_insert
    after insert
    on lignedecommande
    for each row
BEGIN
    DECLARE total_amount DECIMAL(10, 2);
    
    -- Calculer le nouveau total de la commande
    SELECT SUM(prix * quantite) INTO total_amount
    FROM lignedecommande
    WHERE id_commande = NEW.id_commande;

    -- Mettre à jour le champ total dans la table commande
    UPDATE commande
    SET total = total_amount
    WHERE id = NEW.id_commande;
END;

