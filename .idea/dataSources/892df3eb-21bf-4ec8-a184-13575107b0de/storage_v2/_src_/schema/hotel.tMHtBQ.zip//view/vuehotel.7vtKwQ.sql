create definer = admin@localhost view vuehotel as
select `hotel`.`hotel`.`hot_id`        AS `hot_id`,
       `hotel`.`hotel`.`hot_sta_id`    AS `hot_sta_id`,
       `hotel`.`hotel`.`hot_nom`       AS `hot_nom`,
       `hotel`.`hotel`.`hot_categorie` AS `hot_categorie`,
       `hotel`.`hotel`.`hot_adresse`   AS `hot_adresse`,
       `hotel`.`hotel`.`hot_ville`     AS `hot_ville`
from `hotel`.`hotel`;

