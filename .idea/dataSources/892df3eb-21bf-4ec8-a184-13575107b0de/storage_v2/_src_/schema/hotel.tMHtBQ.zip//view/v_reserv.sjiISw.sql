create definer = admin@localhost view v_reserv as
select `hotel`.`reservation`.`res_id`         AS `res_id`,
       `hotel`.`reservation`.`res_cha_id`     AS `res_cha_id`,
       `hotel`.`reservation`.`res_cli_id`     AS `res_cli_id`,
       `hotel`.`reservation`.`res_date`       AS `res_date`,
       `hotel`.`reservation`.`res_date_debut` AS `res_date_debut`,
       `hotel`.`reservation`.`res_date_fin`   AS `res_date_fin`,
       `hotel`.`reservation`.`res_prix`       AS `res_prix`,
       `hotel`.`reservation`.`res_arrhes`     AS `res_arrhes`,
       `hotel`.`client`.`cli_id`              AS `cli_id`,
       `hotel`.`client`.`cli_nom`             AS `cli_nom`,
       `hotel`.`client`.`cli_prenom`          AS `cli_prenom`,
       `hotel`.`client`.`cli_adresse`         AS `cli_adresse`,
       `hotel`.`client`.`cli_ville`           AS `cli_ville`
from `hotel`.`reservation`
         join `hotel`.`client`;

