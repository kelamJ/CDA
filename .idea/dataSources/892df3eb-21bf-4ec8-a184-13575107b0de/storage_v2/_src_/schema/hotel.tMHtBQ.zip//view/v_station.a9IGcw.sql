create definer = admin@localhost view v_station as
select `hotel`.`chambre`.`cha_id`       AS `cha_id`,
       `hotel`.`chambre`.`cha_hot_id`   AS `cha_hot_id`,
       `hotel`.`chambre`.`cha_numero`   AS `cha_numero`,
       `hotel`.`chambre`.`cha_capacite` AS `cha_capacite`,
       `hotel`.`chambre`.`cha_type`     AS `cha_type`,
       `hotel`.`hotel`.`hot_id`         AS `hot_id`,
       `hotel`.`hotel`.`hot_sta_id`     AS `hot_sta_id`,
       `hotel`.`hotel`.`hot_nom`        AS `hot_nom`,
       `hotel`.`hotel`.`hot_categorie`  AS `hot_categorie`,
       `hotel`.`hotel`.`hot_adresse`    AS `hot_adresse`,
       `hotel`.`hotel`.`hot_ville`      AS `hot_ville`,
       `hotel`.`station`.`sta_id`       AS `sta_id`,
       `hotel`.`station`.`sta_nom`      AS `sta_nom`,
       `hotel`.`station`.`sta_altitude` AS `sta_altitude`
from `hotel`.`chambre`
         join `hotel`.`hotel`
         join `hotel`.`station`;

