create definer = admin@localhost trigger modif_reservation
    before update
    on reservation
    for each row
BEGIN
  SIGNAL SQLSTATE '45000'
  SET MESSAGE_TEXT = 'La modification des réservations n\'est pas autorisée.';
END;

